﻿using Microsoft.AspNetCore.Mvc;
using BackendAPI.Services;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using BackendAPI.Model;
using BackendAPI.Models;

namespace BackendAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PayController : ControllerBase
    {
        private readonly PayPalAuthService _payPalAuthService;
        private readonly ILogger<PayController> _logger;

        public PayController(PayPalAuthService payPalAuthService, ILogger<PayController> logger)
        {
            _payPalAuthService = payPalAuthService;
            _logger = logger;
        }

        [HttpPost("CreateProduct")]
        public async Task<IActionResult> CreateProduct([FromBody] paypalProductDto paypalProductDto)
        {
            if (paypalProductDto == null)
            {
                return BadRequest("PaypalProductDto is required.");
            }

            try
            {
                var createdProduct = await _payPalAuthService.CreateProductAsync(paypalProductDto);
                return Ok(createdProduct);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString()); 
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpPost("CreatePlan")]
        public async Task<IActionResult> CreatePlan([FromBody] CreatePlanRequest createPlanRequest)  
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Not vaild"+ModelState);
            }

            try
            {
                var response = await _payPalAuthService.CreatePlanAsync(createPlanRequest); 
                return Ok(response);  
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating plan");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPatch("update-product/{productId}")]
        public async Task<IActionResult> UpdateProduct(string productId, [FromBody] List<PatchProductModel> patchOperations)
        {
            var result = await _payPalAuthService.UpdateProductAsync(productId, patchOperations);
            return Ok("Updated Successfully");
        }

        [HttpPost("CreateSubscription")]
        public async Task<IActionResult> CreateSubscription([FromBody] CreateSubscriptionRequest createSubscriptionRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Not vaild" + ModelState);
            }

            try
            {
                var response = await _payPalAuthService.CreateSubscription(createSubscriptionRequest);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating Subscription");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("CreateCustomer")]
        public async Task<IActionResult> CreateCustomer()
        {
          

            try
            {
                var response = await _payPalAuthService.CreatePayPalVaultCustomer();
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating custok");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
