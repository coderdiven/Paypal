﻿using Newtonsoft.Json;
using System;
using System.Text.Json.Serialization;

namespace BackendAPI.Model
{
    public class CreateSubscriptionRequest
    {
        [JsonProperty("id")]
        public string? id { get; set; }

        [JsonPropertyName("plan_id")]
        public string plan_id { get; set; }

        [JsonPropertyName("start_time")]
        public DateTime start_time { get; set; }


        [JsonPropertyName("shipping_amount")]
        public ShippingAmount shipping_amount { get; set; }

        [JsonPropertyName("subscriber")]
        public Subscriber subscriber { get; set; }

        [JsonPropertyName("application_context")]
        public ApplicationContext application_context { get; set; }
    }

    public class ShippingAmount
    {
        [JsonPropertyName("currency_code")]
        public string currency_code { get; set; }

        [JsonPropertyName("value")]
        public string value { get; set; }
    }

    public class Subscriber
    {
        [JsonPropertyName("name")]
        public Name name { get; set; }

        [JsonPropertyName("email_address")]
        public string email_address { get; set; }

        [JsonPropertyName("shipping_address")]
        public ShippingAddress shipping_address { get; set; }
    }

    public class Name
    {
        [JsonPropertyName("given_name")]
        public string given_name { get; set; }

        [JsonPropertyName("surname")]
        public string surname { get; set; }
    }

    public class ShippingAddress
    {
        [JsonPropertyName("name")]
        public FullName name { get; set; } // Changed to FullName to match JSON

        [JsonPropertyName("address")]
        public Address address { get; set; }
    }

    public class FullName
    {
        [JsonPropertyName("full_name")]
        public string full_name { get; set; }
    }

    public class Address
    {
        [JsonPropertyName("address_line_1")]
        public string address_line_1 { get; set; }

        [JsonPropertyName("address_line_2")]
        public string address_line_2 { get; set; }

        [JsonPropertyName("admin_area_2")]
        public string admin_area_2 { get; set; }

        [JsonPropertyName("admin_area_1")]
        public string admin_area_1 { get; set; }

        [JsonPropertyName("postal_code")]
        public string postal_code { get; set; }

        [JsonPropertyName("country_code")]
        public string country_code { get; set; }
    }

    public class ApplicationContext
    {
        [JsonPropertyName("brand_name")]
        public string brand_name { get; set; }

        [JsonPropertyName("locale")]
        public string locale { get; set; }

        [JsonPropertyName("shipping_preference")]
        public string shipping_preference { get; set; }

        [JsonPropertyName("user_action")]
        public string user_action { get; set; }

        [JsonPropertyName("payment_method")]
        public PaymentMethod payment_method { get; set; }

        [JsonPropertyName("return_url")]
        public string return_url { get; set; }

        [JsonPropertyName("cancel_url")]
        public string cancel_url { get; set; }
    }

    public class PaymentMethod
    {
        [JsonPropertyName("payer_selected")]
        public string payer_selected { get; set; }

        [JsonPropertyName("payee_preferred")]
        public string payee_preferred { get; set; }
    }
}
