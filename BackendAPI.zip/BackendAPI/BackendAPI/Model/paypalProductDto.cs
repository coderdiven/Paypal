﻿using Newtonsoft.Json;

namespace BackendAPI.Model
{
    public class paypalProductDto
    {
        [JsonProperty("id")]
        public string? id { get; set; }
        [JsonProperty("name")]
        public string? name { get; set; }

        [JsonProperty("description")]
        public string? description { get; set; }

        [JsonProperty("type")]
        public string? type { get; set; }

        [JsonProperty("category")]
        public string? category { get; set; }

        [JsonProperty("image_url")]
        public string? image_url { get; set; }

        [JsonProperty("home_url")]
        public string? home_url { get; set; }
    }
}
