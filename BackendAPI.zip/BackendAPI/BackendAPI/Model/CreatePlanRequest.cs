﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace BackendAPI.Models  // Or your preferred namespace
{
    public class CreatePlanRequest
    {
        [JsonProperty("product_id")]
        public string product_id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

        [JsonProperty("description")]
        public string description { get; set; }

        [JsonProperty("billing_cycles")]
        public List<BillingCycles> billing_cycles { get; set; }

        [JsonProperty("payment_preferences")]
        public PaymentPreferences payment_preferences { get; set; }

        [JsonProperty("taxes")]
        public Taxes taxes { get; set; }
    }

    public class BillingCycles
    {
        [JsonProperty("frequency")]
        public Frequency frequency { get; set; }

        [JsonProperty("tenure_type")]
        public string tenure_type { get; set; }

        [JsonProperty("sequence")]
        public int sequence { get; set; }

        [JsonProperty("total_cycles")]
        public int total_cycles { get; set; }

        [JsonProperty("pricing_scheme")]
        public PricingScheme pricing_scheme { get; set; }
    }

    public class Frequency
    {
        [JsonProperty("interval_unit")]
        public string interval_unit { get; set; }

        [JsonProperty("interval_count")]
        public int interval_count { get; set; }
    }

    public class PricingScheme
    {
        [JsonProperty("fixed_price")]
        public FixedPrice fixed_price { get; set; }
    }

    public class FixedPrice
    {
        [JsonProperty("currency_code")]
        public string currency_code { get; set; }

        [JsonProperty("value")]
        public string value { get; set; }
    }

    public class PaymentPreferences
    {
        [JsonProperty("auto_bill_outstanding")]
        public bool auto_bill_outstanding { get; set; }

        [JsonProperty("setup_fee")]
        public SetupFee setup_fee { get; set; }

        [JsonProperty("setup_fee_failure_action")]
        public string setup_fee_failure_action { get; set; }

        [JsonProperty("payment_failure_threshold")]
        public int payment_failure_threshold { get; set; }
    }

    public class SetupFee
    {
        [JsonProperty("value")]
        public string value { get; set; }

        [JsonProperty("currency_code")]
        public string currency_code { get; set; }
    }

    public class Taxes
    {
        [JsonProperty("percentage")]
        public string percentage { get; set; }

        [JsonProperty("inclusive")]
        public bool inclusive { get; set; }
    }
}
