﻿using Newtonsoft.Json;

namespace BackendAPI.Model
{
    public class PatchProductModel
    {

        
            [JsonProperty("op")]
            public string op { get; set; } // "replace", "add", or "remove"

            [JsonProperty("path")]
            public string path { get; set; } // Example: "/description"

            [JsonProperty("value")]
            public string value { get; set; } // New value for the field
        


    }
}
