﻿using Newtonsoft.Json;

namespace BackendAPI.Model
{
    public class CreateCustomerModel
    {
        public PaymentSource payment_source { get; set; }

        public class PaymentSource
        {
            public Card card { get; set; }
        }

        public class Card
        {
            public string number { get; set; }          
            public string expiry { get; set; }          
            public string security_code { get; set; } 
        }
    }
}
