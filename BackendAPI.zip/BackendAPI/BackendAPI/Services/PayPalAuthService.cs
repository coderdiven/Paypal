﻿using Newtonsoft.Json;
using PayPalCheckoutSdk.Core;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using BackendAPI.Model;
using BackendAPI.Models;
namespace BackendAPI.Services
{
    public class PayPalAuthService
    {
        private readonly string clientId = "AaLk85fELHrrbWzXb-vMX8g_jgFKSI5vn4ZBJHJ-kdfQOKbbaPke_1sXkDHVY00W9xu_PDEIowBXKLTV";
        private readonly string clientSecret = "EN_iK4mzqPhmEBAUnKMlZnwbd0mnjRRSPN-nv7Dhl5LS33F_4RgepJsz6TBb0V7tvAyX5T9-owY37vg-";
        private static readonly string baseUrl = "https://api-m.sandbox.paypal.com/";
        private readonly HttpClient _httpClient;
        private string productid { get; set; }
        // ✅ Inject IHttpClientFactory to get HttpClient
        public PayPalAuthService(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient();
        }

        public async Task<string> GetAccessTokenAsync()
        {
            try
            {
                var authString = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{clientId}:{clientSecret}"));
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authString);
                var response = await _httpClient.PostAsync($"{baseUrl}/v1/oauth2/token", new StringContent("grant_type=client_credentials", Encoding.UTF8, "application/x-www-form-urlencoded"));
                var responseContent = await response.Content.ReadAsStringAsync();
                using var jsonDoc = JsonDocument.Parse(responseContent);
                return jsonDoc.RootElement.GetProperty("access_token").GetString();
                Console.WriteLine("token=", jsonDoc);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting PayPal access token: {ex.Message}");
                return string.Empty;
            }
        }

        public async Task<paypalProductDto> CreateProductAsync(paypalProductDto paypalProductDto)
        {
            var accessToken = "A21AAL0dOlyguhnVMSAG2goyNlzvNdInUPEoYjernPlk2RU-MIF4-i-PwXoZP2QabfQGhnXEI_Qg0W_VcicpUGkjNX7gYeI-g";

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);



            var jsonContent = JsonConvert.SerializeObject(paypalProductDto);
            var requestContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");


            var insertProduct = await _httpClient.PostAsync("https://api-m.sandbox.paypal.com/v1/catalogs/products", requestContent);

            if (insertProduct.IsSuccessStatusCode)
            {
                var responseContent = await insertProduct.Content.ReadAsStringAsync();
                Console.WriteLine(responseContent);
                var createdProduct = JsonConvert.DeserializeObject<paypalProductDto>(responseContent);
                //productid = createdProduct.id;
                return createdProduct;
            }
            else
            {
                var errorContent = await insertProduct.Content.ReadAsStringAsync();
                throw new Exception($"Error creating product: {errorContent}");
            }
        }

        public async Task<PatchProductModel> UpdateProductAsync(string ProductId, List<PatchProductModel> patchProductModel)
        {
            var accessToken = "A21AAL4aX6HtEfScjkim2pBqAwtGphhJhzgJ_K6CEnXPii_ltGRwbDpqSyRqKC1eukJupl8Kgv8M_mzLKUV5qFQpaB5mfCYMw";

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);



            var jsonContent = JsonConvert.SerializeObject(patchProductModel);
            var requestContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");


            var UpdatedProduct = await _httpClient.PatchAsync($"https://api-m.sandbox.paypal.com/v1/catalogs/products/{ProductId}", requestContent);

            if (UpdatedProduct.IsSuccessStatusCode)
            {
                var responseContent = await UpdatedProduct.Content.ReadAsStringAsync();
                Console.WriteLine(responseContent);
                var Product = JsonConvert.DeserializeObject<PatchProductModel>(responseContent);
                return Product;
            }
            else
            {
                var errorContent = await UpdatedProduct.Content.ReadAsStringAsync();
                throw new Exception($"Error updating product: {errorContent}");
            }
        }


        public async Task<CreatePlanRequest> CreatePlanAsync(CreatePlanRequest createPlanRequest)
        {
            try
            {
                var accessToken = "A21AAL0dOlyguhnVMSAG2goyNlzvNdInUPEoYjernPlk2RU-MIF4-i-PwXoZP2QabfQGhnXEI_Qg0W_VcicpUGkjNX7gYeI-g";

                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));



                var requestDataJson = JsonConvert.SerializeObject(createPlanRequest);
                var requestContent = new StringContent(requestDataJson, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://api-m.sandbox.paypal.com/v1/billing/plans", requestContent);
                //Console.WriteLine(response);
                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    //Console.WriteLine(responseContent);
                    var createdPlan = JsonConvert.DeserializeObject<CreatePlanRequest>(responseContent);
                    return createdPlan;
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Error creating Plan: {errorContent}");
                }


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<CreateSubscriptionRequest> CreateSubscription(CreateSubscriptionRequest createSubscriptionRequest)
        {
            var accessToken = "A21AAL0dOlyguhnVMSAG2goyNlzvNdInUPEoYjernPlk2RU-MIF4-i-PwXoZP2QabfQGhnXEI_Qg0W_VcicpUGkjNX7gYeI-g";

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var requestDataJson = JsonConvert.SerializeObject(createSubscriptionRequest);
            var requestContent = new StringContent(requestDataJson, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("https://api-m.sandbox.paypal.com/v1/billing/subscriptions", requestContent);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var createdSubscription = JsonConvert.DeserializeObject<CreateSubscriptionRequest>(responseContent);

                return createdSubscription;
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                throw new Exception($"Error creating Subscription: {errorContent}");
            }
        }


        public async Task<string> CreatePayPalVaultCustomer()
        {
            var accessToken = "A21AAIGct3LibSiWk5hE0YdvDWx5_9sHt03I3YGn9xrDZkLiyVAPheEiKAeyAezkS0Nti35p8uHKUXdy9f7n3-M4LMsifwZXw";

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

           var requestBody = new
        {
            source = "CUSTOMER",  // <-- REQUIRED FIELD
            payment_source = new
            {
                card = new
                {
                    number = "4111111111111111",
                    expiry = "2027-12",
                    security_code = "123"
                }
            }
        };
            var requestDataJson = JsonConvert.SerializeObject(requestBody);
            var requestContent = new StringContent(requestDataJson, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("https://api-m.sandbox.paypal.com/v2/vault/payment-tokens", requestContent);
            var responseContent = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                return responseContent;
            }
            else
            {
                throw new Exception($"Error creating Vault Customer: {responseContent}");
            }
        }


    }



}


